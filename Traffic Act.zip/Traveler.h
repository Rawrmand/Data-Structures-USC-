#ifndef Traveler
#define Traveler
#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include <stdlib.h>

typedef struct{
    bool road; // main = true, false = divert
    char direction; // s = straight, l = turning left, r = turning right, p = peds
    int t; // straight (main = 44, diver = 69), Left (main = 80, diver = 75), Right (main = 100, diver = 50), pedestrian (main = 55, diver = 65)
    int pN;
} Travelers;

typedef struct {
    Travelers heap[5];
    int size;
} PriorityQueue;


void initQueue(PriorityQueue*);
void swap(Travelers*, Travelers*);
void insert(PriorityQueue*, Travelers);
Travelers createTraveler (int, char);
bool writeFile(PriorityQueue);
bool readFile();
int totalTimeBeforePN7(PriorityQueue *);
bool writeFile2(PriorityQueue[], int );
bool readFile2(PriorityQueue[], int*);


#endif