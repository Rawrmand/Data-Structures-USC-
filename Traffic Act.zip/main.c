#include "Traveler.h"
/* s = straight, l = turning left, r = turning right, p = peds
   main lane = true, divert lane = false;
   
 */
int main() {
    
    Travelers p[5];
    
    p[0] = createTraveler (1,'s');
    p[1] = createTraveler (0,'l');
    p[2] = createTraveler (0,'r');
    p[3] = createTraveler (1,'p');
    p[4] = createTraveler (1,'s');
    
    PriorityQueue pq;
    PriorityQueue pq2[2];
    
    initQueue(&pq);
    
    int i = 0;
    while(i < 5){
        insert(&pq, p[i]);
        i++;
    }
    
    writeFile(pq);
    readFile(&pq);
    
    int n = 0, x = 3, b = 0, numScenarios = 0;
    char d;
    
    do{
        printf("\nWhat Acitivty needs to be Answered?\n[1] Acitivty 1\n[2] Acitivty 2\n[0] Exit\n");
        scanf("%d",&x);
        printf("\n");
        switch (x){
            case 1:
                if (totalTimeBeforePN7(&pq) != -1) {
                    printf("Total time before pedestrian crosses: %d\n", totalTimeBeforePN7(&pq));
                }
                else{
                     printf("Total time before pedestrian crosses: %d\n", 0);
                }
                break;
            case 2:
                for(n=0;n<=2;n++){
                    initQueue(&(pq2[n]));
                    printf("Input 5 Lanes for Scenario %d\n",n+1);
                    for(int k = 0; k<5; k++){
                        printf("[%d]Which lane? [1]Main [2]Diversion\n",k+1);
                        scanf("%d", &b);
                        
                        printf("[s]Straight [l]Turning Left [r]turning Right [p]]Pedestrian\n");
                        scanf(" %c",&d);
                        p[k] = createTraveler (b,d);
                    }
                    int i = 0;
                    while(i < 5){
                    insert(&pq2[n], p[i]);
                    i++;
                    }
                }
                if (writeFile2(pq2, 2)) {
                    printf("Data written successfully.\n");
                }
                if (readFile2(pq2, &numScenarios)) {
                    printf("Data read successfully. Number of scenarios: %d\n", numScenarios);
                }
                
                break;
            }
    }while(x!=0);
       
    return 0;
}
