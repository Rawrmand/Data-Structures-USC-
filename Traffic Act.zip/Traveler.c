#include "Traveler.h"
// straight (main = 44, diver = 69), Left (main = 80, diver = 75), Right (main = 100, diver = 50), pedestrian (main = 55, diver = 65)
Travelers createTraveler (int r, char d){
    Travelers p;
    
    p.road = r;
    p.direction = d;
    
    if(r == 1){
        switch(d){
            case 's':
                p.t = 44;
                p.pN = 1;
                break;
            case 'l':
                p.t = 80;
                p.pN = 3;
                break;
            case 'r':
                p.t = 100;
                p.pN = 5;
                break;
            case 'p':
                p.t = 55;
                p.pN = 7;
                break;
        }
    }
    else{
        switch(d){
            case 's':
                p.t = 69;
                p.pN = 2;
                break;
            case 'l':
                p.t = 75;
                p.pN = 4;
                break;
            case 'r':
                p.t = 50;
                p.pN = 6;
                break;
            case 'p':
                p.t = 65;
                p.pN = 8;
                break;
        }
    }
    
    return p;
}

bool writeFile(PriorityQueue p) {
    // Open the file in binary write mode
    FILE *file = fopen("traffic.dat", "wb");
    if (file == NULL) {
        printf("Opening file FAILED!\n");
        return false;  // Return false if file opening fails
    }

    // Write the data to the file
    fwrite(p.heap, sizeof(Travelers), p.size, file);  // Write only the valid elements in the heap

    // Close the file and return success
    fclose(file);
    return true;
}

bool readFile(PriorityQueue *pq) {
    // Open the file in binary read mode
    FILE *file = fopen("traffic.dat", "rb");
    if (file == NULL) {
        printf("Error opening file for reading.\n");
        return false;  // Return false if file opening fails
    }

    fseek(file, 0, SEEK_END);
    long fileSize = ftell(file);
    fseek(file, 0, SEEK_SET);

    // Calculate the number of records in the file
    int numRecords = fileSize / sizeof(Travelers);
    
    // Check if the number of records fits into the priority queue
    if (numRecords > 5) {
        printf("Error: too many records in file to fit into priority queue.\n");
        fclose(file);
        return false;
    }

    fread(pq->heap, sizeof(Travelers), numRecords, file);
    pq->size = numRecords;

    for (int i = 0; i < pq->size; i++) {
        printf("Traveler %d: Time = %d, Direction = %c, Priority = %d\n",
               i + 1, pq->heap[i].t, pq->heap[i].direction, pq->heap[i].pN);
    }

    fclose(file);
    return true;
}

// Function to initialize the priority queue
void initQueue(PriorityQueue *pq) {
    pq->size = 0;
}

// Helper function to swap two elements
void swap(Travelers *a, Travelers *b) {
    Travelers temp = *a;
    *a = *b;
    *b = temp;
}

// Function to insert an element into the priority queue
void insert(PriorityQueue *pq, Travelers t) {
    if (pq->size > 5) {
        printf("Priority Queue is full!\n");
        return;
    }
    
    pq->heap[pq->size] = t;
    int current = pq->size;
    pq->size++;

    // Bubble up to maintain the min-heap property (smaller pN = higher priority)
    while (current > 0) {
        int parent = (current - 1) / 2;
        if (pq->heap[current].pN < pq->heap[parent].pN) {
            swap(&pq->heap[current], &pq->heap[parent]);
            current = parent;
        } else {
            break;
        }
    }
}

int totalTimeBeforePN7(PriorityQueue *pq) {
    int totalTime = 0;

    // Ensure the queue is not empty
    if (pq->size == 0) {
        printf("Priority Queue is empty.\n");
        return -1;  // Indicating that the queue is empty
    }

    // Traverse the heap and sum the times of Travelers with pN < 7
    for (int i = 0; i < pq->size; i++) {
        // If pN >= 7, stop adding times and break out of the loop
        if (pq->heap[i].pN >= 7) {
            
            continue;
        }

        // Add time for Travelers with pN < 7
        totalTime += pq->heap[i].t;
    }

    return totalTime;  // Return the total time
}

bool writeFile2(PriorityQueue pq[], int numScenarios) {
    FILE *file = fopen("traffic_result.dat", "w");
    if (file == NULL) {
        printf("Error opening file for writing.\n");
        return false;
    }

    // Write each scenario
    for (int s = 0; s < numScenarios; s++) {
        for (int i = 0; i < pq[s].size; i++) {
            Travelers t = pq[s].heap[i];
            fprintf(file, "%d,%c,%d,%d\n", t.road, t.direction, t.t, t.pN);
        }
        // Separate scenarios with a blank line
        if (s < numScenarios - 1) {
            fprintf(file, "\n");
        }
    }

    fclose(file);
    return true;
}

bool readFile2(PriorityQueue pq[], int *numScenarios) {
    FILE *file = fopen("traffic_result.dat", "r");
    if (file == NULL) {
        printf("Error opening file for reading.\n");
        return false;
    }

    char line[100];
    int currentScenario = 0;
    pq[currentScenario].size = 0;

    // Read each line in the file
    while (fgets(line, sizeof(line), file)) {
        if (strcmp(line, "\n") == 0) {  // Blank line indicates new scenario
            currentScenario++;
            pq[currentScenario].size = 0;
        } else {
            Travelers t;
            sscanf(line, "%d,%c,%d,%d", &t.road, &t.direction, &t.t, &t.pN);

            // Add the traveler to the current scenario's priority queue
            if (pq[currentScenario].size < 5) {
                pq[currentScenario].heap[pq[currentScenario].size++] = t;
            }
        }
    }

    *numScenarios = currentScenario + 1;  // Update the number of scenarios read
    fclose(file);
    return true;
}

/*
1. Straight forward Main Lane
2. Straight forward Diversion Lane
3. Turn Left from Main Lane 
4. Turn Left from Diversion Lane
5. Turn Right from Main Lane
6. Turn Right from Diversion Lane
7. Pedestrian on Main Lane
8. Pedestrian on Diversion Lane
*/